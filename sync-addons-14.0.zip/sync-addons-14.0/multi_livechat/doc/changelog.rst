`1.1.1`
-------

- **Fix:** public channels were not shown
- **Fix:** access error while leaving the channel

`1.1.0`
-------

- **New:** access all channels by clicking channel group title
- **New:** hide channel by clicking a [X] button

`1.0.0`
-------

- **Init version**
