PosBox
======

Official docs:

   * https://www.odoo.com/documentation/user/9.0/point_of_sale/overview/setup.html

.. toctree::
   :maxdepth: 3

   posbox-emulation
   install-posbox-image
   administrate-posbox
   posbox-logs
