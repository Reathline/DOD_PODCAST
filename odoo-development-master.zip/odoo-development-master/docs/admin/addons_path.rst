===================
 ``--addons-path``
===================

Duplicate addons
================

If you have two folder with the same module and you have reason to add both folders to ``addons_path``, then first found version of the module will be used. That is folder in the beginning of ``addons_path`` list has more priority.

