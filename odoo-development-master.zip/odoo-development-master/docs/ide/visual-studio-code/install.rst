============================
 Install Visual Studio Code
============================

 * install visualstudiocode from https://code.visualstudio.com
 * add the following Extensions :
             * python: https://marketplace.visualstudio.com/items?itemName=donjayamanne.python
             * odoo-snippets: https://marketplace.visualstudio.com/items?itemName=jeffery9.odoo-snippets

 * Fallow the same instructions in (emacs-pylint) to install pylint and Pylint Odoo plugin.
   Then make same configurations in pylintrc file as descriped there.

.. attention:: pylintrc file can be placed in the user invirument to work for all projects.
               like for debian "~/.pylintrc"

