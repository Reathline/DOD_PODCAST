Emacs
=====


Install emacs 24.4+ http://askubuntu.com/questions/437255/how-to-install-emacs-24-4-on-ubuntu

* Open Emacs
* Press Alt-x package-list-packages
* install packages: click i and then x
* some packages require dependencies, that have to be installed via terminal
  * flymake
  * loccur
  * flymake-css
  * flymake-jslint
  * flymake-python-pyflakes

    .. code-block:: shell

       sudo pip install flake8

  * magit
  * js3-mode
