===================================
 How to activate debug assets mode 
===================================

Add ``debug=assets`` parameter to your url, e.g.: ::

     localhost:8069/web?debug=assets#
     
or use UI as described below

10.0+
=====  
 
* go to ``Settings``

* click ``Activate the developer mode(with assets)``

.. image:: ../../images/debug-assets-1.png

.. image:: ../../images/debug-assets-2.png
