==================================
 How to enable Technical Features
==================================

8.0
===

* open ``Settings / Users / Users``
* select your user
* click ``[Edit]``
* switch ``Technical Features`` on
* click ``[Save]``
* refresh web page (click ``F5``)

9.0+
====

Since Odoo 9.0 to enable Technical Features you only need to :doc:`activate developer mode<debug-mode>`.
