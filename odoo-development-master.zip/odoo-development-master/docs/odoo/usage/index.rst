How to use Odoo
===============

.. toctree::
   :maxdepth: 3

   create-database
   technical-features
   install-module
   debug-mode
   debug-assets-mode
   login-as-superuser
