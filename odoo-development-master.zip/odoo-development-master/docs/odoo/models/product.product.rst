product.product
===============

The product, unlike the :doc:`template <product.template>`, it is a separate product that can be calculated, set the price, to assign a discount.

product.product is used:

* sale.order
* stock
* pos
