Models
======

Section helps in understanding built-in models

.. toctree::
   :maxdepth: 3

   ir.config_parameter
   res.users
   res.groups
   ir.model.access
   ir.rule
   product.template
   product.product
   ir.actions.todo
   bus.bus
   ir.cron
   mail.message

..   product
..
..   stock.move
