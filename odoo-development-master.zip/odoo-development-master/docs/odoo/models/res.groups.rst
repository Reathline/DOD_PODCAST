res.groups
==========

TODO

