product.template
================

The stores have products that differ from some other only a one or few properties. Such goods it makes no sense to separate as individual products. They are join in a group of similar goods, which are called **template**.

**shop:** product pages use product.template (when order is created, then :doc:`product.product` is used).
