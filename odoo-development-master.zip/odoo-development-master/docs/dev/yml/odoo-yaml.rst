YAML in odoo
============

TODO
