YAML
====

.. toctree::

   pure-yaml
   odoo-yaml
