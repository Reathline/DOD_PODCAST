Compare two arrays
==================

  a = set(pos_config_obj.floor_ids.ids)
  b = set(rec.floor_ids.ids)
  diff = a.difference(b)

