Odoo Python
===========

.. toctree::

   decorators
   python/index
   res.config.settings
   controllers
   one2one
   x2many
   fields
   constraints
   postgres-views
   external-imports
