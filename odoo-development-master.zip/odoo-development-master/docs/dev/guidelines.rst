============
 Guidelines
============

Source:

* https://www.odoo.com/documentation/8.0/reference/guidelines.html

Comments
========

First of all, comments in the source are required if it's not obvious **why** are doing something.

Additionally, you can add comments about **what** are you doing, if it could be helpful.
