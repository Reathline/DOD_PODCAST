==================
 Superuser rights
==================

Administrator, i.e. user with id 1 (``SUPERUSER_ID``), has exceptions about access rights.

ir.model.access
===============

If some model doesn't have records in :doc:`ir.model.access (Access Rules)<../../odoo/models/ir.model.access>`, then only Administrator has access to that model.
