Access
======

.. toctree::

   tutorial.rst
   admin

See also:

* :doc:`ir.model.access <../../odoo/models/ir.model.access>`
* :doc:`ir.rule <../../odoo/models/ir.rule>`

Video Lessons 
-------------

* `Правила доступа <https://www.youtube.com/watch?v=wRJ_hvXKF0E>`__ (Russian)
