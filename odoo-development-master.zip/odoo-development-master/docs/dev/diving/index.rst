===============
 Source Diving
===============


`Source Diving <https://yelizariev.github.io/odoo/development/2015/04/17/source-diving.html>`_ is a way to find answers to your questions.

.. toctree::

   cases/index
   transformed_method
   cases/transformed_method
