XML
===

.. toctree::

   create-records
   xpath
   qweb
   inherit
   group-id-in-views
   actions-menu
