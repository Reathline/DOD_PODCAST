=================================
 Fixing Javascript lints in odoo
=================================
::

    #lint for js:
    fixmyjs --legacy --config ~/.jshintrc ./

