=====================
 Point of Sale (POS)
=====================

New POS Module
==============

.. toctree::

   adding-js
   odoo-define
   inheritance

UI extending
============

.. toctree::

   action-buttons
   custom-popup
   custom-screen

Receipts & Printers
===================

.. toctree::
   custom-receipt

Extra Order Data
================


.. toctree::

   load-data-to-pos
   custom-order-data
   send-pos-orders-to-server

Instant syncronization
======================

.. toctree::

   longpolling
   ms-support

Advanced POS Development
========================

.. toctree::

   dom-cache
   gui
