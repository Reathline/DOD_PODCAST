Inheritance
===========

   TODO
