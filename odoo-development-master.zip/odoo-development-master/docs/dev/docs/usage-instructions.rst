===============
 doc/index.rst
===============

* This description will be available in App store under *Documentation* tab. Example: https://www.odoo.com/apps/modules/8.0/pos_multi_session/

* Does not use OCA

* IT-Projects' ``doc/index.rst`` is available here: https://gitlab.com/itpp/handbook/blob/master/technical-docs/usage-instruction.md
