============
 README.rst
============

OCA's README
------------

* https://raw.githubusercontent.com/OCA/maintainer-tools/master/template/module/README.rst

IT-Projects' README
----------------------

* https://gitlab.com/itpp/handbook/blob/master/technical-docs/README.rst.md