Other
=====

.. toctree::

   dynamic-records
   odoo
