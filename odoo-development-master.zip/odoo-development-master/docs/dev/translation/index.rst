============================
 Odoo Translation Framework
============================

.. toctree::
   :maxdepth: 2
   
   overwrite-translation
