====================================
 Sources tab at Browser's dev tools
====================================

Allows you to check which client side files are loaded and which are not. To do this:

1. Turn on *debug mode (with assets)*

2. Open Developer tools (F12), go to the Sources tab and reload page.

3. Open left panel (if it is not open yet) and search interested app.

Example:  :doc:`Missing dependencies error in console <errors/missing-dependencies>`

