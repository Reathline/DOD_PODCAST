===================
 Browser's Console
===================


Browser's console (short name: *console*) may contain userfull logs about client part.

To open console Click F12 in browser.
