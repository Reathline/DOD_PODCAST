===========
 Debugging
===========

This section describes how to find the reason of existing problem.

.. toctree::
   :maxdepth: 2

   terminal-output
   browser-console
   browser-sources
   browser-network
   qweb
   errors/index
