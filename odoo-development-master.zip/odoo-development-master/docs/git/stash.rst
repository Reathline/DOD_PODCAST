Git stash
=========

* book: https://git-scm.com/book/no-nb/v1/Git-Tools-Stashing
* man: https://git-scm.com/docs/git-stash
