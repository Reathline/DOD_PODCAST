Git and Github
==============

.. toctree::
   :maxdepth: 3

   init
   porting
   conflicts
   multi-pull-request
   reset
   utils
   remote
   files-relocation
   stash
   git_update
   squash
   checkout-pr
