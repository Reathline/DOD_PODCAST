Pull request from console
-------------------------

Yes it possible! Try this manual: https://github.com/github/hub
Than in console::

 alias git=hub

And pull request::

 git pull-request upstream 9.0

Nessesary to add some header for pull request. Save it. If everything is ok you will got link to your pull request.
