First steps
===========

* `Install odoo <https://xoe-labs.github.io/dockery-odoo/>`__
* take the course `Building a module <https://www.odoo.com/documentation/10.0/howtos/backend.html>`_
* read the article `Source diving <https://yelizariev.github.io/odoo/development/2015/04/17/source-diving.html>`_
* Get tasks from your Guru!
* Fork repo, clone repo to you machine, make commits, push updates, create Pull Request
