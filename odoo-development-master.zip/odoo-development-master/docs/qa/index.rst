===================
 Quality assurance
===================

.. note:: The section moved and now is available `here <https://itpp.dev/test/>`__.

   
