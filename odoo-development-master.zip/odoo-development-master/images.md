Images
======

Images must be put to ``docs/images/`` directory.

Then use a code:

    .. image:: ../../path/to/image.png

Maximum size for image is 695 px.
