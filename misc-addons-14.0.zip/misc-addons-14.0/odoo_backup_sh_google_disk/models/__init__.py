# Copyright 2019 Dinar Gabbasov <https://it-projects.info/team/GabbasovDinar>
# License MIT (https://opensource.org/licenses/MIT).
from . import res_config_settings
from . import ir_config_parameter
from . import odoo_backup_sh
