`1.1.0`
-------

- **Improvement**: Added helper function `set_max_records` to `base.limit.records_number`

`1.0.0`
-------

- Init version
