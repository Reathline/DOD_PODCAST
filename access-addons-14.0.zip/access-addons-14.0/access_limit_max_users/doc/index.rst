=======================
 Limit number of users
=======================

Installation
============
* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Usage
=====

* Open menu ``[[ Settings ]] >> Users & Companies >> Users``
* Click ``[Create]``
* Fill in required fields. Usually they are `Name` and `Email Address`
* RESULT: you will see exception message, that says that you cannot create more records.
