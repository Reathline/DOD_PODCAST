`1.1.1`
-------

- **Fix**: Fixed impossibility to successfully edit any user

`1.1.0`
-------

- **Improvement**: Added field `is_excluded_from_limiting` to Users model to exclude certain records, when limiting number of users

`1.0.0`
-------

- **Init version**
