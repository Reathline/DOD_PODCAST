============
 Quick Auth
============

Installation
============

Follow insturction of the module `Quick Auth (Master) <https://apps.odoo.com/apps/modules/12.0/auth_quick_master/>`__

Configuration
=============

* `Activate Developer Mode <https://odoo-development.readthedocs.io/en/latest/odoo/usage/debug-mode.html>`__
* Open menu ``[[ Settings ]] >> Technical >> Parameters >> System Parameters``
* Create following key-value records:

  * ``auth_quick.master`` -- url to master server.
  * ``auth_quick.build`` -- reference for this database

Usage
=====

Follow instruction of the module `Quick Auth (Master) <https://apps.odoo.com/apps/modules/12.0/auth_quick_master/>`__
