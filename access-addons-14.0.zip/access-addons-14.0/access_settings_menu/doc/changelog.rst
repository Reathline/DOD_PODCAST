`1.0.2`
-------

- FIX: make compatible with CI-tests of other modules


`1.0.1`
-------

- FIX issue occured when user has ``[x] Show Settings Menu`` access, but doesn't have administration rights

`1.0.0`
-------

- Init version
