`1.1.1`
-------

- **Fix:** in cases when the database expires today or tomorrow no reminder was shown

`1.1.0`
-------

- **New**: ``database_expiration_warning_delay`` option
- **New**: Ability to add hyperlink in warning/expiration message

`1.0.0`
-------

- **Init version**
