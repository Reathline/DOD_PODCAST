`2.3.1`
-------

 - **FIX:** properly handling longpolling error

`2.3.0`
-------

- **IMP:** File refactoring. Changes after Pull request https://github.com/odoo/odoo/pull/28092 to Odoo was merged

`2.2.0`
-------

- **IMP:** *Autostart longpolling* field is hidden on the `POS config` form to prevent possible misconfigurations.

`2.1.2`
-------

 - **FIX:** Incorrect behaviour of longpolling icons

`2.1.1`
-------

 - **FIX:** Error related to endless longpolling ping requests and multiple event triggering on changing network status

`2.1.0`
-------

- **IMP:** Change minutes to seconds for Max Silence Timeout and Pong timeout
- **FIX:** Correct working after switch a device to sleep mode
- **NEW:** Restore longpolling conection by clicking the icon
- **NEW:** New orange colour for longpolling icon

`2.0.1`
-------

- **IMP:** Sync icons for deactivated pollings are hidden
- **FIX:** Longpolling recovering on very bad internet connection is fixed

`2.0.0`
-------

- **NEW:** Support multiple buses with different channels for longpolling requests
- **NEW:** Additional longpolling connection status in POS interface

`1.1.1`
-------

- **FIX:** longpolling channel

`1.1.0`
-------

- **NEW:** longpolling connection status in POS interface

`1.0.0`
-------

- Init version
