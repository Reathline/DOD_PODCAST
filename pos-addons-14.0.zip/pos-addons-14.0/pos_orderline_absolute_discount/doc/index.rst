===========================
 Absolute Discounts in POS
===========================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Usage
=====

* Go to ``Point of Sale`` menu
* Open POS session
* Add a product to order
* Make a double-click on ``[Disc]`` button
  (The button turns color to blue)
* Specify a discount value by using numpad
* RESULT: see absolute discount for orderline
