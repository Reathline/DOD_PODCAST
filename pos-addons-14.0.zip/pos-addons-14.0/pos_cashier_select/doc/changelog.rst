`1.0.2`
-------

**Fix:** Incompatibility with pos_scan_ref module

`1.0.1`
-------

**Fix:** Incompatibility with pos_product_category_discount module

`1.0.0`
-------

**Init version**
